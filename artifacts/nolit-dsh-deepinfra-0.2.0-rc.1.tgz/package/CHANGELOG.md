# CHANGELOG — @nolit/dsh-deepinfra

<!-- skeleton:
version: 1.1
kind: report
status: active
updated: 2026-11-04
summary: Every change to this track with measured before/after: the 0.1.0-rc.1 adapter, five brief assumptions the live API contradicted, and the 0.2.0 production integration (settings UI, cost chip, ledger, i18n) with the four real-boot defects it exposed.
-->

> History for this plugin only (RULES §6.1). Measurements that outlive one plugin belong in
> root `docs/`. Every entry states what was measured, not what was intended.

## 0.2.0-rc.1 — production integration (2026-11-04)

Settings UI, composer cost chip, persistent usage ledger, full i18n and strict style conformance,
replicating the verified opencode-v2 implementation.

### What was added

| Area | Surface | Evidence it works |
|---|---|---|
| Credential | `apiKey` as `role('secret')` in the cordis schema; UI value wins, `DEEPINFRA_API_KEY` is the fallback | `redactSecrets` strips the field; `setup` returns `set:true` and a masked tail only |
| Cost chip | `conversation.input.activity` slot, gated on provider id | rendered beside the model selector with `providerId: deepinfra` |
| Ledger | `deepinfra-session-cost.json`, partitioned by session, model and turn | real turn wrote `requests: 3, turns: ["1"]` |
| Usage routes | `/api/local/deepinfra/{cost/session,cost/summary,cost/reset,setup,setup/apply}` | HTTP 200 from the authenticated browser context |
| i18n | 35 keys × en/ko, inlined tables | panel renders `Loading DeepInfra settings…` / `딥인프라 설정을 불러오는 중…` |
| Style | 14px/22px root, `--dsw-*` tokens only | client test asserts zero literal colours and no `@import` |

### Four defects that only a REAL BOOT exposed

Every one of these passed `node --check`, the unit suite and `--dump-config`.

**1. `ctx.profileDir` without inject — whole entry down.**
```
dsh-deepinfra (@nolit/dsh-deepinfra): Error: cannot get property "profileDir" without inject
dsh: warning: 1 entry did not activate
```
Fixed with an `optional(ctx, name)` guard. `test/entry-contract.test.mjs` now asserts every
`ctx.<service>` read is declared.

**2. A web-only service gated the model route.**
Declaring `inject = ['llm','connection','settings']` made a HEADLESS profile hang:
```
dsh-deepinfra: pending (waiting for service: connection)
dsh: NO_ADAPTER: no adapter registered for provider "deepinfra"
```
`connection` and `settings` are web-only. `inject` is now `['llm']` and the panel mounts through
`ctx.inject(['connection'], …)`, so a headless profile serves models and never mounts the panel.

**3. The client is a CommonJS factory, not an ES module.**
Two separate boot failures, both `web boot: 1 entry did not activate`:
`import … with { type: 'json' }` → `Cannot use import statement outside a module`;
`export` statements → `Unexpected token 'export'`.
The file is now the `window.__ModuleLoader__.load({ id, factory })` shape the reference proves.

**4. The invented route seam.**
`ctx.connection.register` does not exist; the real seam is `ctx.connection.fetch.register`.
The guess answered **404 on all four routes** while the unit suite was green, because the test
fake invented the same wrong shape. The fake now mirrors the measured host and a second test
asserts a host without `fetch.register` degrades with a warning instead of throwing.

### Turn attribution

`GenerateOptions` carries no turn field, and `agent/turn-stopping` announces a turn as it
**closes** — so the announced number is one behind the requests it describes. Measured: using the
raw value left every request `unassigned`; using `lastCompleted + 1` partitions a 3-call turn
into exactly turn 1.

### Verification

| Gate | Result |
|---|---|
| keyless CI | 132 pass, **7 self-skip**, 0 fail |
| full suite with key | **139/139**, 0 skipped |
| `node --check` all 11 modules | pass |
| isolated web boot | **0** activation warnings, stylesheet injected |
| settings routes | HTTP 200 authenticated; catalog 91; masked key |
| client component executes | real VM evaluation renders both languages |
| live state untouched | `~/.dsh/profiles/web` has no deepinfra row |

## 0.1.0-rc.1 — initial build (2026-11-04)

First working adapter: one `deepinfra` route, no daemon, no spawn, no credential store.

### Five brief assumptions the live API contradicted

| # | Brief claim | Measured reality | Consequence |
|---|---|---|---|
| 1 | Cost is derived, not reported | `usage.estimated_cost` is exact USD on **every** completion | provider value used verbatim |
| 2 | Hard 16,384 output cap | No wire cap; 50000/100000 return 200. On all 91 chat routes `max_tokens === context_length` | no clamp; reservation is the turn policy |
| 3 | Stop: up to 4 sequences | 4/5/8/16 → 200; **32** → 422 "maximum of 16" | `MAX_STOP_SEQUENCES = 16` |
| 4 | 57 of 148 rows lack `context_length` | **0 of 91** chat routes lack it | context always populated |
| 5 | `reasoning_effort` on a non-reasoning model has no effect | `DeepSeek-V3.2` (neither tag) emitted **50** reasoning deltas with an effort, **0** without | tags drive advertisement only |

Two facts settled the design: `metadata.discount` is a fraction to subtract (fitted ratios 0.70 /
0.75 / 0.75 / 1.00), and `prompt_tokens` is the TOTAL with `cached_tokens` a subset.

### Wire shapes measured

| Fact | Measurement |
|---|---|
| SSE framing | one `data: {json}` line, blank-line separated, `data: [DONE]` |
| Usage ordering | usage arrives **after** `finish_reason` |
| Reasoning | `delta.reasoning_content` streams as deltas |
| Tool calls | first fragment has id/name with empty arguments; later ones carry only an arguments slice with `id:null` |
| Roles | `system`, `user`, `assistant`, `tool`, `developer` all accepted |
| Images | `{type:'image_url', image_url:{url:'data:…'}}` accepted |

### Defect found only by a real turn

`block-end` emitted `{type:'text', text:''}` instead of the assembled block, so a turn that
streamed 5 tokens completed with an **empty message**. Before: `"text":""`; after:
`"text":"MOUNT-OK"`. Three regression tests added.
