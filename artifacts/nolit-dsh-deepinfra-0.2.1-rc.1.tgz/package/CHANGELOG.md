# CHANGELOG — @nolit/dsh-deepinfra

<!-- skeleton:
version: 1.2
kind: report
status: active
updated: 2026-11-04
summary: Every change to this track with measured before/after: the 0.1.0-rc.1 adapter, five brief assumptions the live API contradicted, the 0.2.0 production integration, and the 0.2.1 architecture correction (config-layer credentials, model selection UI, production registration).
-->

> History for this plugin only (RULES §6.1). Measurements that outlive one plugin belong in
> root `docs/`. Every entry states what was measured, not what was intended.

## 0.2.1-rc.1 — architecture correction & hardening (2026-11-04)

Owner directive: credential resolution must come from the DSH configuration layer, models must be
selectable with promotions visible, packaging must be automatic, and both plugins' docs must match
host standards.

### Defect A — the settings UI could not save anything at all

**Measured.** `SettingsForms.write()` computes `volatileForm(schema)` and throws
`Plugin entry "…" has no volatile fields` when it resolves to undefined. My schema had **zero**
`.volatile()` fields, so a key typed into the Web UI could never be persisted — which is exactly
why the credential story appeared to require a systemd edit.

| Before | After |
|---|---|
| 0 volatile fields; `volatileForm` → undefined; save throws | 7 volatile fields; `volatileForm` resolves to all of them |
| key had to be injected as `!!js process.env.DEEPINFRA_API_KEY` in the patch | key is entered once in the UI and persisted by the host |
| a saved key would be shadowed by the pinned expression on every boot | patch default is `''`; the saved value wins |

Verified end-to-end with **no environment variable set in the shell**:
`setup` → `{ apiKeySource: 'none' }`; `setup/apply` → HTTP 200; `setup` → `{ apiKeySource: 'ui',
hasApiKey: true, apiKey: 'sk-di-…bNY9' }`; a real turn then completed with `CONFIG-KEY-OK` while
`DEEPINFRA_API_KEY` was `ABSENT`.

A dedicated test (`test/entry-contract.test.mjs`) now reproduces the host's `volatileForm` gate so
the regression cannot return silently.

### Defect B — the settings service was read from the wrong context

**Measured.** After moving the panel mount to `ctx.inject(['connection'], …)`, `setup/apply`
answered **HTTP 409 "this host exposes no settings service"** on the live page, because the server
read the ROOT `ctx.settings`, which does not own that service once the panel mounts through a
deferred sub-context.

Fix: the deferred context is now `ctx.inject(['connection','settings'], …)` and `server.js` keeps
that scope, preferring it in `services()`. A test mounts with a scope-only settings service and
asserts the write lands.

### Feature — model selection with promotions

`POST /api/local/deepinfra/models` and `/models/apply` back a new **Served models** card.

- 91 chat routes with effective and list price per million tokens, context, and
  `vision`/`reasoning` badges.
- **8 of 91 carry `metadata.discount`** (0.10 – 0.75). There is no featured/promo tag — the catalog
  tag vocabulary is capability only — so the offer is derived in `catalog.promotionOf()` and the
  list sorts promotional routes first, deepest discount at the top.
- Search box, All/None, and a save that round-trips through the settings service.

Live proof (authenticated browser context, no env key):
`MODELS total: 91 | promotions: 8`, first row `inclusionAI/Ling-3.1-flash | 75% off | out $0.225`
with list `$0.900` struck through.

### Feature — automatic production registration

The plugin was packed (`artifacts/nolit-dsh-deepinfra-0.2.0-rc.1.tgz`, 17 files) and registered
into `~/.dsh/profiles/web` with `dsh plugin --profile web add link:…`, matching the sibling
convention (every other `@nolit/*` track is a link dependency).

| Step | Result |
|---|---|
| package name asserted before packaging (RULES §3) | `@nolit/dsh-deepinfra` |
| `npm pack` | 17 files, tgz verified by `tar -tzf` |
| live profile dependency | `@nolit/dsh-deepinfra` added |
| live profile bundle | appended to `dsh.profile.bundles` |
| credential | written into the profile patch, so no unit edit is needed |
| live service | **not restarted** — still the 21:43:46 process |
| backup | `package.json.bak.before-deepinfra-20261104_234944` |

### Docs

- New `ARCHITECTURE.md` for this track: layer ownership, the credential path with its three
  required properties, the stream contract, the error taxonomy, the service-declaration rule, the
  client module format, the slot contract, the ledger schema and the promotion model.
- New `ARCHITECTURE.md` for `dsh-opencode-v2`, documenting control plane vs serving plane, its
  five-service declaration and why it differs from the minimal `['llm']` here, plus the explicit
  "same wire format, no shared code" rationale.
- README rewritten for config-layer credentials and the model selection UI.

### Verification

| Gate | Result |
|---|---|
| keyless suite | 138 pass, **7 self-skip**, 0 fail |
| `node --check` | 11 modules pass |
| live compose (`--dump-config`) | OK, row present |
| UI-saved key | `source: ui`, masked tail only |
| turn from config key with no env | `CONFIG-KEY-OK` |
| models route | 91 routes, 8 promotions, promo-first ordering |
| live service | untouched (`active`, started 21:43:46) |

## 0.2.0-rc.1 — production integration (2026-11-04)

Settings UI, composer cost chip, persistent usage ledger, full i18n and strict style conformance,
replicating the verified opencode-v2 implementation.

### What was added

| Area | Surface | Evidence it works |
|---|---|---|
| Credential | `apiKey` as `role('secret')` in the cordis schema; UI value wins, `DEEPINFRA_API_KEY` is the fallback | `redactSecrets` strips the field; `setup` returns `set:true` and a masked tail only |
| Cost chip | `conversation.input.activity` slot, gated on provider id | rendered beside the model selector with `providerId: deepinfra` |
| Ledger | `deepinfra-session-cost.json`, partitioned by session, model and turn | real turn wrote `requests: 3, turns: ["1"]` |
| Usage routes | `/api/local/deepinfra/{cost/session,cost/summary,cost/reset,setup,setup/apply}` | HTTP 200 from the authenticated browser context |
| i18n | 35 keys × en/ko, inlined tables | panel renders `Loading DeepInfra settings…` / `딥인프라 설정을 불러오는 중…` |
| Style | 14px/22px root, `--dsw-*` tokens only | client test asserts zero literal colours and no `@import` |

### Four defects that only a REAL BOOT exposed

Every one of these passed `node --check`, the unit suite and `--dump-config`.

**1. `ctx.profileDir` without inject — whole entry down.**
```
dsh-deepinfra (@nolit/dsh-deepinfra): Error: cannot get property "profileDir" without inject
dsh: warning: 1 entry did not activate
```
Fixed with an `optional(ctx, name)` guard. `test/entry-contract.test.mjs` now asserts every
`ctx.<service>` read is declared.

**2. A web-only service gated the model route.**
Declaring `inject = ['llm','connection','settings']` made a HEADLESS profile hang:
```
dsh-deepinfra: pending (waiting for service: connection)
dsh: NO_ADAPTER: no adapter registered for provider "deepinfra"
```
`connection` and `settings` are web-only. `inject` is now `['llm']` and the panel mounts through
`ctx.inject(['connection'], …)`, so a headless profile serves models and never mounts the panel.

**3. The client is a CommonJS factory, not an ES module.**
Two separate boot failures, both `web boot: 1 entry did not activate`:
`import … with { type: 'json' }` → `Cannot use import statement outside a module`;
`export` statements → `Unexpected token 'export'`.
The file is now the `window.__ModuleLoader__.load({ id, factory })` shape the reference proves.

**4. The invented route seam.**
`ctx.connection.register` does not exist; the real seam is `ctx.connection.fetch.register`.
The guess answered **404 on all four routes** while the unit suite was green, because the test
fake invented the same wrong shape. The fake now mirrors the measured host and a second test
asserts a host without `fetch.register` degrades with a warning instead of throwing.

### Turn attribution

`GenerateOptions` carries no turn field, and `agent/turn-stopping` announces a turn as it
**closes** — so the announced number is one behind the requests it describes. Measured: using the
raw value left every request `unassigned`; using `lastCompleted + 1` partitions a 3-call turn
into exactly turn 1.

### Verification

| Gate | Result |
|---|---|
| keyless CI | 132 pass, **7 self-skip**, 0 fail |
| full suite with key | **139/139**, 0 skipped |
| `node --check` all 11 modules | pass |
| isolated web boot | **0** activation warnings, stylesheet injected |
| settings routes | HTTP 200 authenticated; catalog 91; masked key |
| client component executes | real VM evaluation renders both languages |
| live state untouched | `~/.dsh/profiles/web` has no deepinfra row |

## 0.1.0-rc.1 — initial build (2026-11-04)

First working adapter: one `deepinfra` route, no daemon, no spawn, no credential store.

### Five brief assumptions the live API contradicted

| # | Brief claim | Measured reality | Consequence |
|---|---|---|---|
| 1 | Cost is derived, not reported | `usage.estimated_cost` is exact USD on **every** completion | provider value used verbatim |
| 2 | Hard 16,384 output cap | No wire cap; 50000/100000 return 200. On all 91 chat routes `max_tokens === context_length` | no clamp; reservation is the turn policy |
| 3 | Stop: up to 4 sequences | 4/5/8/16 → 200; **32** → 422 "maximum of 16" | `MAX_STOP_SEQUENCES = 16` |
| 4 | 57 of 148 rows lack `context_length` | **0 of 91** chat routes lack it | context always populated |
| 5 | `reasoning_effort` on a non-reasoning model has no effect | `DeepSeek-V3.2` (neither tag) emitted **50** reasoning deltas with an effort, **0** without | tags drive advertisement only |

Two facts settled the design: `metadata.discount` is a fraction to subtract (fitted ratios 0.70 /
0.75 / 0.75 / 1.00), and `prompt_tokens` is the TOTAL with `cached_tokens` a subset.

### Wire shapes measured

| Fact | Measurement |
|---|---|
| SSE framing | one `data: {json}` line, blank-line separated, `data: [DONE]` |
| Usage ordering | usage arrives **after** `finish_reason` |
| Reasoning | `delta.reasoning_content` streams as deltas |
| Tool calls | first fragment has id/name with empty arguments; later ones carry only an arguments slice with `id:null` |
| Roles | `system`, `user`, `assistant`, `tool`, `developer` all accepted |
| Images | `{type:'image_url', image_url:{url:'data:…'}}` accepted |

### Defect found only by a real turn

`block-end` emitted `{type:'text', text:''}` instead of the assembled block, so a turn that
streamed 5 tokens completed with an **empty message**. Before: `"text":""`; after:
`"text":"MOUNT-OK"`. Three regression tests added.
